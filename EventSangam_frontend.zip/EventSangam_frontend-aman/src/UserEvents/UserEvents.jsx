import { useEffect, useState } from "react";
import { useAppContext } from "../App/App";
import { useNavigate } from "react-router-dom";
import PreviewBusiness from "../Business/PreviewBusiness";
import "./UserEvents.css";
import { biError, biSuccess, fetchData, notify } from "../functions";
import NoPage from "../NoPage/NoPage";

const UserEvents = () => {
  let { client } = useAppContext();
  const navigate = useNavigate();
  const [expandedEvent, setExpandedEvent] = useState(null);
  const [loadingEvents, setLoadingEvents] = useState(true);
  const [events, setEvents] = useState([]);

  useEffect(() => {
    const getUserEvents = async () => {
      let data = await fetchData({
        fetchUrl: `event/fetch_user_events/${client.current.cid}`,
        method: "GET",
      });
      if (data.events) {
        setEvents(data.events);
      } else if (data.message) {
        notify(biError, data.message);
      } else {
        notify(biError, "Something Went Wrong");
      }

      setLoadingEvents(false);
    };

    getUserEvents();
  }, [client]);

  const handleShowMore = (index) => {
    setExpandedEvent(expandedEvent === index ? null : index);
  };

  const handleUpdate = (eid) => {
    navigate(`/hostEvent/${eid}`);
  };

  const handleDelete = async (eid) => {
    let data = await fetchData({
      fetchUrl: `event/cancel_event/${eid}/${client.current.cid}`,
      method: "GET",
    });

    if (data.event) {
      notify(biSuccess, data.message);
      setEvents((prev) => prev.filter((event) => event.eid !== eid));
    } else if (data.message) {
      notify(biError, data.message);
    } else {
      notify(biError, "Something Went Wrong");
    }
  };

  const markComplete = async (eid, index) => {
    let data = await fetchData({
      fetchUrl: `event/mark_complete/${eid}`,
      method: "GET",
    });

    if (data.updated) {
      notify(biSuccess, "Event Completed");
      let e = events[index];
      e["status"] = "completed";
      events[index] = e;
      let new_events = events;
      setEvents([...new_events]);
    } else {
      notify(biError, "Error Completing Event");
    }
  };

  let plannedEvents = events.filter((event) => event.status === "planned");
  let completedEvents = events.filter((event) => event.status === "completed");

  return loadingEvents ? (
    <NoPage loading />
  ) : events.length ? (
    <>
      <ul
        className="nav nav-tabs user-events row container-fluid"
        id="eventTypeTabs"
      >
        <li className="nav-item col">
          <button
            className="nav-link active"
            data-bs-toggle="tab"
            data-bs-target="#planned"
          >
            Planned
          </button>
        </li>
        <li className="nav-item col">
          <button
            className="nav-link"
            data-bs-toggle="tab"
            data-bs-target="#completed"
          >
            Completed
          </button>
        </li>
      </ul>
      <div className="tab-content user-events mt-3">
        <div className="tab-pane scrollable fade show active" id="planned">
          <div
            style={{ maxHeight: "100%" }}
            className="scrollable container-fluid"
          >
            {plannedEvents.length ? (
              plannedEvents.map((event, index) => (
                <>
                  <div key={event.eid} className="card mb-4">
                    <div className="d-flex flex-column">
                      <div>
                        <h2>
                          {event.event_type} on {event.date}
                        </h2>
                        <p>At {event.venue.name}</p>
                      </div>
                      <div className=" d-flex justify-content-between align-items-center">
                        <div>
                          <button
                            className="cus_btn block important outlinedBtn"
                            onClick={() => handleShowMore(index)}
                          >
                            {expandedEvent === index
                              ? "Show less"
                              : "Show more"}
                          </button>
                        </div>
                        {event.date ===
                          new Date().toISOString().split("T")[0] && (
                          <div>
                            <button
                              className="outlinedBtn cus_btn"
                              onClick={() => markComplete(event.eid, index)}
                            >
                              Mark Complete
                            </button>
                          </div>
                        )}

                        <div>
                          <button
                            className="cus_btn block filledBtn"
                            onClick={() => handleUpdate(event.eid)}
                          >
                            Update
                          </button>
                        </div>
                        <div>
                          <button
                            className="cus_btn block important"
                            onClick={() => handleDelete(event.eid)}
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    </div>
                    <div
                      className={`collapse mt-3  ${
                        expandedEvent === index ? "show" : ""
                      }`}
                      id={`collapseEvent${index}`}
                    >
                      <ul
                        className="nav nav-tabs d-flex justify-content-between"
                        id={`eventTabs${index}`}
                      >
                        <li className="nav-item">
                          <button
                            className="nav-link active"
                            data-bs-toggle="tab"
                            data-bs-target={`#venue${index}`}
                          >
                            Venue
                          </button>
                        </li>
                        <li className="nav-item">
                          <button
                            className="nav-link"
                            data-bs-toggle="tab"
                            data-bs-target={`#planners${index}`}
                          >
                            Planners
                          </button>
                        </li>
                        <li className="nav-item">
                          <button
                            className="nav-link"
                            data-bs-toggle="tab"
                            data-bs-target={`#caters${index}`}
                          >
                            Caters
                          </button>
                        </li>
                        <li className="nav-item">
                          <button
                            className="nav-link"
                            data-bs-toggle="tab"
                            data-bs-target={`#photographers${index}`}
                          >
                            Photographers
                          </button>
                        </li>
                      </ul>
                      <div className="tab-content mt-3">
                        <div
                          className="tab-pane scrollable fade show active"
                          id={`venue${index}`}
                        >
                          <PreviewBusiness businessData={event.venue} />
                        </div>
                        <div
                          className="tab-pane scrollable fade"
                          id={`planners${index}`}
                        >
                          <ul className="list-group">
                            {event.planners?.map((planner) => (
                              <li
                                key={planner.name}
                                className="list-group-item"
                              >
                                <PreviewBusiness businessData={planner} />
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div
                          className="tab-pane scrollable fade"
                          id={`caters${index}`}
                        >
                          <ul className="list-group">
                            {event.caters?.map((cater) => (
                              <li key={cater.name} className="list-group-item">
                                <PreviewBusiness businessData={cater} />
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div
                          className="tab-pane scrollable fade"
                          id={`photographers${index}`}
                        >
                          <ul className="list-group">
                            {event.photographers?.map((photographer) => (
                              <li
                                key={photographer.name}
                                className="list-group-item"
                              >
                                <PreviewBusiness businessData={photographer} />
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              ))
            ) : (
              <NoPage notFoundText={"No Planned Events"} />
            )}
          </div>
        </div>
        <div className="tab-pane scrollable fade show" id="completed">
          <div
            style={{ maxHeight: "100%" }}
            className="scrollable container-fluid"
          >
            {completedEvents.length ? (
              completedEvents.map((event, index) => (
                <>
                  <div key={event.eid} className="card mb-4">
                    <div className="d-flex flex-column">
                      <div>
                        <h2>
                          {event.event_type} on {event.date}
                        </h2>
                        <p>At {event.venue.name}</p>
                      </div>
                      <div>
                        <button
                          className="cus_btn  important outlinedBtn"
                          onClick={() => handleShowMore(index)}
                        >
                          {expandedEvent === index ? "Show less" : "Show more"}
                        </button>
                      </div>
                    </div>
                    <div
                      className={`collapse mt-3 ${
                        expandedEvent === index ? "show" : ""
                      }`}
                      id={`collapseEvent${index}`}
                    >
                      <ul className="nav nav-tabs row" id={`eventTabs${index}`}>
                        <li className="nav-item col-6 col-md-3">
                          <button
                            className="nav-link active"
                            data-bs-toggle="tab"
                            data-bs-target={`#venue${index}`}
                          >
                            Venue
                          </button>
                        </li>
                        <li className="nav-item col-6 col-md-3">
                          <button
                            className="nav-link"
                            data-bs-toggle="tab"
                            data-bs-target={`#planners${index}`}
                          >
                            Planners
                          </button>
                        </li>
                        <li className="nav-item col-6 col-md-3">
                          <button
                            className="nav-link"
                            data-bs-toggle="tab"
                            data-bs-target={`#caters${index}`}
                          >
                            Caters
                          </button>
                        </li>
                        <li className="nav-item col-6 col-md-3">
                          <button
                            className="nav-link"
                            data-bs-toggle="tab"
                            data-bs-target={`#photographers${index}`}
                          >
                            Photographers
                          </button>
                        </li>
                      </ul>
                      <div className="tab-content mt-3">
                        <div
                          className="tab-pane scrollable fade show active"
                          id={`venue${index}`}
                        >
                          <PreviewBusiness businessData={event.venue} />
                        </div>
                        <div
                          className="tab-pane scrollable fade"
                          id={`planners${index}`}
                        >
                          <ul className="list-group">
                            {event.planners?.map((planner) => (
                              <li
                                key={planner.name}
                                className="list-group-item"
                              >
                                <PreviewBusiness businessData={planner} />
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div
                          className="tab-pane scrollable fade"
                          id={`caters${index}`}
                        >
                          <ul className="list-group">
                            {event.caters?.map((cater) => (
                              <li key={cater.name} className="list-group-item">
                                <PreviewBusiness businessData={cater} />
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div
                          className="tab-pane scrollable fade"
                          id={`photographers${index}`}
                        >
                          <ul className="list-group">
                            {event.photographers?.map((photographer) => (
                              <li
                                key={photographer.name}
                                className="list-group-item"
                              >
                                <PreviewBusiness businessData={photographer} />
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              ))
            ) : (
              <NoPage notFoundText={"No Completed Events"} />
            )}
          </div>
        </div>
      </div>
    </>
  ) : (
    <NoPage notFoundText={"No Events Found"} />
  );
};

export default UserEvents;
