import "./Register.css";
import { useState } from "react";
import { biError, fetchData, notify } from "../functions";
import { Link, useNavigate } from "react-router-dom";

const Register = ({ setLoggedUser, client }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    email: "",
    confirmPassword: "",
    mobile: "",
    address: "",
  });

  const handleChange = (e) => {
    let { name, value } = e.target;
    if (value.trim()) {
      setFormData((prev) => {
        return { ...prev, [name]: value };
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let notFilled = Object.entries(formData)?.find(([key, value]) => !value);
    if (notFilled?.length) {
      notify(biError, `${notFilled[0]} Is Required!!`);
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      notify(biError, "Passwords Do not Match!!");
      return;
    }

    let data = await fetchData({ fetchUrl: "register", data: formData });
    if (!data.error && data.user) {
      setLoggedUser(data.user);
      client.current = { ...data.user };
      localStorage.setItem("token", JSON.stringify(data.token));
      navigate("/");
    } else if (data.message) {
      notify(biError, data.message);
    } else {
      notify(biError, "Something Went Wrong!!!");
    }
  };

  return (
    <>
      <section className="register-container">
        <div
          className="color"
          style={{
            top: "-350px",
            width: "700px",
            height: "700px",
            background: "#ff359b",
          }}
        ></div>
        <div
          className="color"
          style={{
            bottom: "-100px",
            left: "300px",
            width: "600px",
            height: "600px",
            background: "#ffdd87",
          }}
        ></div>
        <div
          className="color"
          style={{
            bottom: "50px",
            right: "400px",
            width: "400px",
            height: "400px",
            background: "#00d2ff",
          }}
        ></div>
        <div className="box">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="square" style={{ "--i": i }}></div>
          ))}
          <div className="container">
            <div className="form">
              <h2>Register Form</h2>
              <form onSubmit={handleSubmit} action="">
                <div className="inputbox">
                  <input
                    type="text"
                    placeholder="Username"
                    name="username"
                    onChange={handleChange}
                    autoComplete="username"
                  />
                </div>
                <div className="inputbox">
                  <input
                    type="password"
                    placeholder="Password"
                    name="password"
                    onChange={handleChange}
                    autoComplete="new-password"
                  />
                </div>
                <div className="inputbox">
                  <input
                    type="password"
                    placeholder="Confirm password"
                    name="confirmPassword"
                    onChange={handleChange}
                    autoComplete="new-password"
                  />
                </div>
                <div className="inputbox">
                  <input
                    type="email"
                    placeholder="Email"
                    name="email"
                    onChange={handleChange}
                    autoComplete="email"
                  />
                </div>
                <div className="inputbox">
                  <input
                    type=""
                    placeholder="Mobile"
                    name="mobile"
                    onChange={handleChange}
                  />
                </div>
                <div className="inputbox">
                  <textarea
                    placeholder="Address"
                    name="address"
                    onChange={handleChange}
                  />
                </div>
                <div className="inputbox">
                  <input type="submit" value="Register" />
                </div>
                <p className="toLogin">
                  Already have an account? <Link to="/login">Log In</Link>
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Register;
