import React, { useState, useEffect } from "react";
import Business from "../Business/Business";
import { fetchData, notify, biError } from "../functions";
import NoPage from "../NoPage/NoPage";

const PlannerExplore = () => {
  const [planners, setPlanners] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getPlanners = async () => {
      let data = await fetchData({
        fetchUrl: `business/get_available_planners/`,
        method: "GET",
      });

      if (data.planners) {
        setPlanners(data.planners);
      } else if (data.error) {
        notify(biError, "Cannot Fetch Planners!!!");
      }
      setLoading(false);
    };

    getPlanners();
  }, []);

  return !loading ? (
    planners.length ? (
      <div style={{maxHeight : "100%"}} className="scrollable">
        {planners.map((planner, index) => {
          return (
            <Business
              isExploring
              businessData={planner}
              key={`planner ${index}`}
            />
          );
        })}
      </div>
    ) : (
      <NoPage notFoundText={"No Planners Found"} />
    )
  ) : (
    <NoPage loading />
  );
};

export default PlannerExplore;
