import React, { useState, useEffect } from "react";
import Business from "../Business/Business";
import { fetchData, notify, biError } from "../functions";
import NoPage from "../NoPage/NoPage";

const PhotographerExplore = () => {
  const [photographers, setPhotographers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getPhotographers = async () => {
      let data = await fetchData({
        fetchUrl: `business/get_available_photographers/`,
        method: "GET",
      });

      if (data.photographers) {
        setPhotographers(data.photographers);
      } else if (data.error) {
        notify(biError, "Cannot Fetch Photographers!!!");
      }
      setLoading(false);
    };

    getPhotographers();
  }, []);

  return !loading ? (
    photographers.length ? (
      <div style={{ maxHeight: "100%" }} className="scrollable">
        {photographers.map((photographer, index) => {
          return (
            <Business
              isExploring
              businessData={photographer}
              key={`photographer ${index}`}
            />
          );
        })}
      </div>
    ) : (
      <NoPage notFoundText={"No Photographers Found"} />
    )
  ) : (
    <NoPage loading />
  );
};

export default PhotographerExplore;
