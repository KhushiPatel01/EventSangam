import React, { useState, useEffect } from "react";
import Business from "../Business/Business";
import { fetchData, notify, biError } from "../functions";
import NoPage from "../NoPage/NoPage";

const CaterExplore = () => {
  const [caters, setCaters] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getCaters = async () => {
      let data = await fetchData({
        fetchUrl: `business/get_available_caters/`,
        method: "GET",
      });

      if (data.caters) {
        setCaters(data.caters);
      } else if (data.error) {
        notify(biError, "Cannot Fetch Caters!!!");
      }
      setLoading(false);
    };

    getCaters();
  }, []);

  return !loading ? (
    caters.length ? (
      <div style={{ maxHeight: "100%" }} className="scrollable">
        {caters.map((cater, index) => {
          return (
            <Business isExploring businessData={cater} key={`cater ${index}`} />
          );
        })}
      </div>
    ) : (
      <NoPage notFoundText={"No Caters Found"} />
    )
  ) : (
    <NoPage loading />
  );
};

export default CaterExplore;
