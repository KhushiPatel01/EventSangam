import { useState, useEffect } from "react";
import "./Explore.css";
import NoPage from "../NoPage/NoPage";
import Venue from "../Venue/Venue";
import { fetchData, notify, biError } from "../functions";

const VenueExplore = () => {
  const [venues, setVenues] = useState([]);
  const [loadingVenues, setLoadingVenues] = useState(true);

  useEffect(() => {
    const getVenues = async () => {
      let data = await fetchData({
        fetchUrl: `business/get_available_venues/`,
        method: "GET",
      });

      if (data.venues) {
        setVenues(data.venues);
      } else if (data.error) {
        notify(biError, "Cannot Fetch Venues!!!");
      }
      setLoadingVenues(false);
    };

   getVenues();
  }, []);

  return !loadingVenues ? (
    venues.length ? (
      <div style={{maxHeight : "100%"}} className="scrollable">
        {venues.map((venue, index) => {
          return <Venue isExploring venue={venue} key={`venue ${index}`} />;
        })}
      </div>
    ) : (
      <NoPage notFoundText={"No Venues Found"} />
    )
  ) : (
    <NoPage loading />
  );
};

export default VenueExplore;
