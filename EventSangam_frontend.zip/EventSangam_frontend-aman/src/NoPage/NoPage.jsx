const NoPage = ({ loading, notFoundText }) => {
  if (loading) {
    return (
      <div className="loading d-flex justify-content-center align-items-center w-100 h-100">
        <div className="loading-spinner">
          <div
            className="spinner-border"
            style={{ color: "var(--important_bg)" }}
          ></div>
        </div>
      </div>
    );
  } else if (notFoundText) {
    return (
      <div className="text-center align-content-center h-50">
        {notFoundText}
      </div>
    );
  }
};

export default NoPage;
