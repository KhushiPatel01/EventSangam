import { useState } from "react";
import { useAppContext } from "../App/App";
import { fetchData, notify, biError } from "../functions";

const Ratings = ({ business }) => {
  let { client } = useAppContext();
  let id = business.vid || business.bid;
  const [ratedBusinesses, setRatedBusinesses] = useState(
    client.current.rated_businesses
  );
  let oldRatings = ratedBusinesses[id] || 0;

  const handleRatingClick = async (newRating) => {
    if (newRating !== oldRatings) {
      let newlyRated = { ...ratedBusinesses, [id]: newRating };
      setRatedBusinesses(newlyRated);
      client.current.rated_businesses = newlyRated;

      let data = await fetchData({
        fetchUrl: `business/update_ratings/${newRating}/${oldRatings}/${
          client.current?.cid
        }/${business.bid ? "b" : "v"}/${id}`,
        method: "GET",
      });

      if (!data.error) {
        business.ratings = data.ratings;
      } else {
        notify(biError, "Could Not Update Ratings!!");
      }
    }
  };

  const handleRateRemove = async () => {
    let newlyRated = ratedBusinesses;
    delete newlyRated[id];
    setRatedBusinesses({ ...newlyRated });
    client.current.rated_businesses = newlyRated;

    let data = await fetchData({
      fetchUrl: `business/update_ratings/${0}/${oldRatings}/${
        client.current?.cid
      }/${business.bid ? "b" : "v"}/${id}`,
      method: "GET",
    });

    if (!data.error) {
      business.ratings = data.ratings;
    } else {
      notify(biError, "Could Not Update Ratings!!");
    }
  };

  return (
    <div className="d-flex justify-content-between pb-2 pb-md-0">
      <div className="d-flex align-items-center cus_btn">
        {[1, 2, 3, 4, 5].map((star) => {
          return (
            <i
              key={star}
              onClick={(e) => {
                handleRatingClick(star);
              }}
              className={`bi px-1 ${
                star > oldRatings ? "bi-star" : "bi-star-fill"
              }`}
              style={{
                cursor: "pointer",
                color: star > oldRatings ? "inherit" : "var(--important_bg)",
                height: "100%",
              }}
            ></i>
          );
        })}
      </div>
      {client.current?.rated_businesses[id] && (
        <div>
          <button
            className="important outlinedBtn block cus_btn"
            onClick={(e) => {
              handleRateRemove();
            }}
          >
            Remove Ratings
          </button>
        </div>
      )}
    </div>
  );
};

export default Ratings;
