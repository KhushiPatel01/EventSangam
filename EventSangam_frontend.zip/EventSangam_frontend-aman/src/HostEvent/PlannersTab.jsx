import { useCallback, useEffect, useState, useRef } from "react";
import Business from "../Business/Business";
import { biError, fetchData, notify } from "../functions";
import SortFilter from "./SortFilter";
import NoPage from "../NoPage/NoPage";

const PlannersTab = ({ eventData, setEventData }) => {
  let plannersRef = useRef([]);
  const [loadingPlanners, setLoadingPlanners] = useState(true);
  const [planners, setPlanners] = useState([]);
  let eventPlannersBids = (eventData.planners || []).map(
    (planner) => planner.bid
  );

  useEffect(() => {
    const getAvailablePlanners = async () => {
      let data = await fetchData({
        fetchUrl: `business/get_available_planners/${eventData.date}`,
        method: "GET",
      });

      if (data.planners) {
        if (eventPlannersBids.length) {
          let filtered = data.planners.filter(
            (planner) => !eventPlannersBids.includes(planner.bid)
          );
          filtered = [...eventData.planners, ...filtered];
          setPlanners(filtered);
          plannersRef.current = filtered;
        } else {
          setPlanners(data.planners);
          plannersRef.current = data.planners;
        }
      } else if (data.error) {
        notify(biError, "Cannot Fetch Planners!!!");
      }

      setLoadingPlanners(false);
    };

    if (!plannersRef.current.length) {
      getAvailablePlanners();
    }
  }, [plannersRef, eventData.date, eventData.planners, eventPlannersBids]);

  const handlePlannerAdd = useCallback(
    (planner) => {
      setEventData((prev) => {
        return { ...prev, planners: [...(prev.planners || []), planner] };
      });
    },
    [setEventData]
  );

  const handlePlannerRemove = useCallback(
    (bid) => {
      setEventData((prev) => {
        return {
          ...prev,
          planners: (prev.planners || []).filter(
            (planner) => planner.bid !== bid
          ),
        };
      });
    },
    [setEventData]
  );

  return loadingPlanners ? (
    <NoPage loading />
  ) : planners.length ? (
    <>
      <div style={{ maxHeight: "20%" }}>
        <SortFilter
          date={eventData.date}
          business="Planning"
          objs={planners}
          requiredObjIds={eventPlannersBids}
          setObjs={setPlanners}
          originalObjs={plannersRef}
        />
      </div>
      <div>
        {planners.map((planner, index) => (
          <Business
            key={`Planner ${index + 1}`}
            businessData={planner}
            onAdd={handlePlannerAdd}
            onRemove={handlePlannerRemove}
            currentAddedBids={eventPlannersBids}
          />
        ))}
      </div>
    </>
  ) : (
    <NoPage notFoundText={"No Planners Found"} />
  );
};

export default PlannersTab;
