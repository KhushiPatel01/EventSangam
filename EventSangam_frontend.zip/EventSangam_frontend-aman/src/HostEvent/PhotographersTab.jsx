import { useCallback, useEffect, useRef, useState } from "react";
import Business from "../Business/Business";
import { biError, fetchData, notify } from "../functions";
import SortFilter from "./SortFilter";
import NoPage from "../NoPage/NoPage";

const PhotographersTab = ({ eventData, setEventData }) => {
  let photographersRef = useRef([]);
  const [loadingPhotographers, setLoadingPhotographers] = useState(true);
  const [photographers, setPhotographers] = useState([]);
  let eventphotographersBids = (eventData.photographers || []).map(
    (photographer) => photographer.bid
  );

  useEffect(() => {
    const getAvailablePhotographers = async () => {
      let data = await fetchData({
        fetchUrl: `business/get_available_photographers/${eventData.date}`,
        method: "GET",
      });

      if (data.photographers) {
        if (eventphotographersBids.length) {
          let filtered = data.photographers.filter(
            (photographer) => !eventphotographersBids.includes(photographer.bid)
          );
          filtered = [...eventData.photographers, ...filtered];
          setPhotographers(filtered);
          photographersRef.current = filtered;
        } else {
          setPhotographers(data.photographers);
          photographersRef.current = data.photographers;
        }
      } else if (data.error) {
        notify(biError, "Cannot Fetch Photographers!!!");
      }

      setLoadingPhotographers(false);
    };

    if (!photographersRef.current.length) {
      getAvailablePhotographers();
    }
  }, [
    photographers,
    eventData.date,
    eventData.photographers,
    eventphotographersBids,
  ]);

  const handlephotographerAdd = useCallback(
    (photographer) => {
      setEventData((prev) => {
        return {
          ...prev,
          photographers: [...(prev.photographers || []), photographer],
        };
      });
    },
    [setEventData]
  );

  const handlephotographerRemove = useCallback(
    (bid) => {
      setEventData((prev) => {
        return {
          ...prev,
          photographers: (prev.photographers || []).filter(
            (photographer) => photographer.bid !== bid
          ),
        };
      });
    },
    [setEventData]
  );

  return loadingPhotographers ? (
    <NoPage loading />
  ) : photographers.length ? (
    <>
      <div style={{ maxHeight: "20%" }}>
        <SortFilter
          date={eventData.date}
          business="Photography"
          objs={photographers}
          requiredObjIds={eventphotographersBids}
          setObjs={setPhotographers}
          originalObjs={photographersRef}
        />
      </div>
      <div>
        {photographers.map((photographer, index) => (
          <Business
            key={`photographer ${index + 1}`}
            businessData={photographer}
            onAdd={handlephotographerAdd}
            onRemove={handlephotographerRemove}
            currentAddedBids={eventphotographersBids}
          />
        ))}
      </div>
    </>
  ) : (
    <NoPage notFoundText={"No Photographers Found"} />
  );
};

export default PhotographersTab;
