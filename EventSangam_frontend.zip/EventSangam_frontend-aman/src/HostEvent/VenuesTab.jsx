import { useCallback, useEffect, useRef, useState } from "react";
import Venue from "../Venue/Venue";
import { fetchData, notify, biError } from "../functions";
import SortFilter from "./SortFilter";
import NoPage from "../NoPage/NoPage";

const VenuesTab = ({ eventData, setEventData }) => {
  let venuesRef = useRef([]);
  const [venues, setVenues] = useState([]);
  const [loadingVenues, setLoadingVenues] = useState(true);

  useEffect(() => {
    const getAvailableVenues = async () => {
      let data = await fetchData({
        fetchUrl: `business/get_available_venues/${eventData.date}`,
        method: "GET",
      });

      if (data.venues) {
        if (eventData.venue) {
          let filtered = data.venues.filter(
            (venue) => eventData.venue.vid !== venue.vid
          );
          filtered = [eventData.venue, ...filtered];
          setVenues(filtered);
          venuesRef.current = filtered;
        } else {
          setVenues(data.venues);
          venuesRef.current = data.venues;
        }
      } else if (data.error) {
        notify(biError, "Cannot Fetch Venues!!!");
      }
      setLoadingVenues(false);
    };

    if (!venuesRef.current.length) {
      getAvailableVenues();
    }
  }, [venuesRef.current.length, eventData.date, eventData.venue]);

  const handleVenueAdd = useCallback(
    (vid) => {
      let venue = venues.find((venue) => venue.vid === vid);
      if (venue) {
        setEventData((prev) => {
          return { ...prev, venue };
        });
      }
    },
    [setEventData, venues]
  );

  const handleVenueRemove = useCallback(() => {
    setEventData((prev) => {
      return { ...prev, venue: null };
    });
  }, [setEventData]);

  return (
    <>
      {loadingVenues ? (
        <NoPage loading />
      ) : venues.length ? (
        <>
          <div style={{ maxHeight: "20%" }}>
            <SortFilter
              date={eventData.date}
              business="v"
              requiredObjIds={[eventData.venue?.vid]}
              objs={venues}
              setObjs={setVenues}
              originalObjs={venuesRef}
            />
          </div>
          <div>
            {venues.map((venue, index) => {
              return (
                <Venue
                  onAdd={() => {
                    handleVenueAdd(venue.vid);
                  }}
                  onRemove={handleVenueRemove}
                  addedVenueId={eventData.venue?.vid}
                  venue={venue}
                  key={`venue ${index}`}
                />
              );
            })}
          </div>
        </>
      ) : (
        <NoPage notFoundText={"No Venues Found"} />
      )}
    </>
  );
};

export default VenuesTab;
