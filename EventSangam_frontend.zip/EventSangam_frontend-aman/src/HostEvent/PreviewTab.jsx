import { useNavigate } from "react-router-dom";
import { useAppContext } from "../App/App";
import { biError, biSuccess, fetchData, notify } from "../functions";
import { useState } from "react";

const PreviewTab = ({ eventData, hostedEventId }) => {
  let { client } = useAppContext();
  const navigate = useNavigate();
  const [eventSaved, setEventSaved] = useState(false);

  const handleSave = async () => {
    if (Object.entries(eventData).some(([key, value]) => value === null)) {
      notify(biError, "You Have not Added Required Data");
    } else {
      eventData["planners"] = eventData["planners"].map(
        (planner) => planner.bid
      );
      eventData["caters"] = eventData["caters"].map((cater) => cater.bid);
      eventData["photographers"] = eventData["photographers"].map(
        (photographer) => photographer.bid
      );
      eventData["venue"] = eventData["venue"].vid;

      const hostEvent = async () => {
        let data = await fetchData({
          fetchUrl: "event/host_event",
          data: { cid: client.current.cid, ...eventData },
        });

        if (!data.error && data.event) {
          let hostedEvents = client.current?.hosted_events || [];
          client.current.hosted_events = [data.event, ...hostedEvents];
          setEventSaved(true);
          navigate("/profile");
        } else {
          notify(biError, "Something Went Wrong!!!");
        }

        if (data.message) {
          if (data.event) {
            notify(biSuccess, data.message);
          } else {
            notify(biError, data.message);
          }
        }
      };

      const updateEvent = async () => {
        let data = await fetchData({
          fetchUrl: "event/update_event",
          data: { ...eventData },
        });

        if (!data.error && data.event) {
          let hostedEvents = client.current?.hosted_events || [];
          hostedEvents = hostedEvents.filter(
            (event) => event.eid !== data.event.eid
          );
          hostedEvents = [data.event, ...hostedEvents];
          client.current.hosted_events = hostedEvents;
          setEventSaved(true);
          navigate("/profile");
        } else {
          notify(biError, "Something Went Wrong!!!");
        }

        if (data.message) {
          if (data.event) {
            notify(biSuccess, data.message);
          } else {
            notify(biError, data.message);
          }
        }
      };

      if (!hostedEventId) {
        hostEvent();
      } else {
        updateEvent();
      }
    }
  };
  return (
    <div className="d-flex flex-column container-fluid preview pb-5">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">
            {eventData.event_type} On {eventData.date}
          </h4>
          <p class="card-text">At {eventData.venue?.name || "Where??"}</p>
        </div>
        <ul>
          <li>
            <h6 className="display-6">Planners</h6>
            <ul className="list-group list-group-flush my-2">
              {eventData.planners?.length ? (
                eventData.planners.map((planner, index) => (
                  <li className="list-group-item" key={`Planner ${index + 1}`}>
                    {planner.name}
                  </li>
                ))
              ) : (
                <li className="list-group-item">Not Selected Any</li>
              )}
            </ul>
          </li>
          <li>
            <h6 className="display-6">Caters</h6>
            <ul className="list-group list-group-flush my-2">
              {eventData.caters?.length ? (
                eventData.caters.map((cater, index) => (
                  <li className="list-group-item" key={`Cater ${index + 1}`}>
                    {cater.name}
                  </li>
                ))
              ) : (
                <li className="list-group-item">Not Selected Any</li>
              )}
            </ul>
          </li>
          <li>
            <h6 className="display-6">Photographers</h6>
            <ul className="list-group list-group-flush my-2">
              {eventData.photographers?.length ? (
                eventData.photographers.map((photographer, index) => (
                  <li
                    className="list-group-item"
                    key={`Photographer ${index + 1}`}
                  >
                    {photographer.name}
                  </li>
                ))
              ) : (
                <li className="list-group-item">Not Selected Any</li>
              )}
            </ul>
          </li>
        </ul>
        <div className=" card-footer">
          {!eventSaved && (
            <div className="my-2">
              <button onClick={handleSave} className="cus_btn block filledBtn">
                Save
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PreviewTab;
