import { useCallback, useEffect, useRef, useState } from "react";
import Business from "../Business/Business";
import { biError, fetchData, notify } from "../functions";
import SortFilter from "./SortFilter";
import NoPage from "../NoPage/NoPage";

const CatersTab = ({ eventData, setEventData }) => {
  let catersRef = useRef([]);
  const [caters, setCaters] = useState([]);
  const [loadingCaters, setLoadingCaters] = useState(true);
  let eventcatersBids = (eventData.caters || []).map((cater) => cater.bid);

  useEffect(() => {
    const getAvailableCaters = async () => {
      let data = await fetchData({
        fetchUrl: `business/get_available_caters/${eventData.date}`,
        method: "GET",
      });
      if (data.caters) {
        if (eventcatersBids.length) {
          let filtered = data.caters.filter(
            (cater) => !eventcatersBids.includes(cater.bid)
          );
          filtered = [...eventData.caters, ...filtered];
          setCaters(filtered);
          catersRef.current = filtered;
        } else {
          setCaters(data.caters);
          catersRef.current = data.caters;
        }
      } else if (data.error) {
        notify(biError, "Cannot Fetch Caters!!!");
      }
      setLoadingCaters(false);
    };

    if (!catersRef.current.length) {
      getAvailableCaters();
    }
  }, [catersRef, eventData.date, eventData.caters, eventcatersBids]);

  const handlecaterAdd = useCallback(
    (cater) => {
      setEventData((prev) => {
        return {
          ...prev,
          caters: [...(prev.caters || []), cater],
        };
      });
    },
    [setEventData]
  );

  const handlecaterRemove = useCallback(
    (bid) => {
      setEventData((prev) => {
        return {
          ...prev,
          caters: (prev.caters || []).filter((cater) => cater.bid !== bid),
        };
      });
    },
    [setEventData]
  );

  return loadingCaters ? (
    <NoPage loading />
  ) : caters.length ? (
    <>
      <div style={{ maxHeight: "20" }}>
        <SortFilter
          date={eventData.date}
          business="Catering"
          objs={caters}
          requiredObjIds={eventcatersBids}
          setObjs={setCaters}
          originalObjs={catersRef}
        />
      </div>
      <div>
        {caters.map((cater, index) => (
          <Business
            key={`cater ${index + 1}`}
            businessData={cater}
            onAdd={handlecaterAdd}
            onRemove={handlecaterRemove}
            currentAddedBids={eventcatersBids}
          />
        ))}
      </div>
    </>
  ) : (
    <NoPage notFoundText={"No Caters Found"} />
  );
};

export default CatersTab;
