import { useState } from "react";
import { biError, getMinMaxDates, notify } from "../functions";

const BasicDetails = ({ eventData, setEventData, setChangingBasicDetails }) => {
  const eventTypes = [
    "Wedding",
    "Corporate Conference",
    "Birthday Party",
    "Charity Gala",
    "Trade Show",
    "Music Festival",
    "Sports Event",
    "Product Launch",
    "Workshop/Seminar",
    "Family Reunion",
  ];

  const dates = getMinMaxDates();

  const [basicDetails, setBasicDetails] = useState({
    event_type: eventData.event_type,
    date: eventData.date,
  });

  const handleSumbit = (e) => {
    e.preventDefault();
    if (basicDetails.date && basicDetails.event_type) {
      setEventData((prev) => {
        return { ...prev, ...basicDetails };
      });
      setChangingBasicDetails(false);
    } else {
      notify(biError, "All Details Are Required To Proceed!!");
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center w-100 h-75">
      <form
        onSubmit={handleSumbit}
        style={{ border: "2px solid var(--important_bg)" }}
        className="p-3"
      >
        <div className="dropdown dp">
          <button
            className="cus_btn block important dropdown-toggle"
            type="button"
            data-bs-toggle="dropdown"
          >
            {basicDetails.event_type || "Event Type"}
          </button>
          <div className="dropdown-menu imp">
            {eventTypes.map((type, index) => (
              <button
                type="button"
                onClick={() => {
                  setBasicDetails((prev) => {
                    return { ...prev, event_type: type };
                  });
                }}
                key={`Event Type ${index + 1}`}
                className="dropdown-item"
              >
                {type}
              </button>
            ))}
          </div>
        </div>
        <div className="my-3">
          <label htmlFor="date" className="form-label">
            Date
          </label>
          <input
            type="date"
            className="form-control"
            name="date"
            id="date"
            min={dates.minDate}
            max={dates.maxDate}
            onChange={(e) => {
              setBasicDetails((prev) => {
                return { ...prev, date: e.target.value };
              });
            }}
            value={basicDetails.date || ""}
            placeholder="Enter Event Date"
          />
        </div>
        <p className=" text-center my-2 text-danger fs-4">
          Refreshing or Leaving This Page will Abandon The process
        </p>
        <button type="submit" className="cus_btn block important">
          Proceed
        </button>
      </form>
    </div>
  );
};

export default BasicDetails;
