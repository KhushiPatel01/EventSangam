import "./HostEvent.css";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { biError, fetchData, notify } from "../functions";
import BasicDetails from "./BasicDetails";
import NoPage from "../NoPage/NoPage";
import VenuesTab from "./VenuesTab";
import PlannersTab from "./PlannersTab";
import Caterstab from "./CatersTab";
import PhotographersTab from "./PhotographersTab";
import PreviewTab from "./PreviewTab";

const HostEvent = () => {
  const [loadingEvent, setLoadingEvent] = useState(false);
  const [eventData, setEventData] = useState({
    event_type: null,
    date: null,
    planners: null,
    caters: null,
    photographers: null,
    venue: null,
  });
  const [changingBasicDetails, setChangingBasicDetails] = useState(true);
  const { hostedEventId } = useParams();

  useEffect(() => {
    const getHostedEvent = async () => {
      setLoadingEvent(true);
      let data = await fetchData({
        fetchUrl: `event/fetch_event/${hostedEventId}`,
        method: "GET",
      });

      if (data.event) {
        setEventData(data.event);
      } else if (data.error) {
        notify(biError, "Something Went Wrong!!!");
      } else {
        setEventData(null);
      }

      setLoadingEvent(false);
    };

    if (hostedEventId) {
      getHostedEvent();
    }
  }, [hostedEventId]);

  if (!loadingEvent) {
    if (eventData) {
      if (!changingBasicDetails) {
        return (
          <>
            <ul
              className="nav nav-tabs row pt-1 pb-2 mb-2 align-items-center"
              id="hostEventTabs"
            >
              <li className="nav-item col-md-2 col-6">
                <button
                  className="nav-link active"
                  data-bs-toggle="tab"
                  data-bs-target="#venue"
                  type="button"
                >
                  Venue
                </button>
              </li>
              <li className="nav-item col-md-2 col-6">
                <button
                  className="nav-link"
                  data-bs-toggle="tab"
                  data-bs-target="#planner"
                  type="button"
                >
                  Planner
                </button>
              </li>
              <li className="nav-item col-md-2 col-6">
                <button
                  className="nav-link"
                  data-bs-toggle="tab"
                  data-bs-target="#cater"
                  type="button"
                >
                  Cater
                </button>
              </li>
              <li className="nav-item col-md-2 col-6">
                <button
                  className="nav-link"
                  data-bs-toggle="tab"
                  data-bs-target="#photograph"
                  type="button"
                >
                  Photographer
                </button>
              </li>
              <li className="nav-item col-md-2 col-12">
                <button
                  className="nav-link block_md"
                  data-bs-toggle="tab"
                  data-bs-target="#preview"
                  type="button"
                >
                  Preview
                </button>
              </li>
              <li className="nav-item col-md-2 col-sm-12">
                <button
                  onClick={() => {
                    setChangingBasicDetails(true);
                  }}
                  className="important block_md"
                  type="button"
                >
                  Change Settings
                </button>
              </li>
            </ul>

            <div
              style={{ height: "100%" }}
              className="tab-content scrollable pb-5"
            >
              <div className="tab-pane fade show active" id="venue">
                <VenuesTab eventData={eventData} setEventData={setEventData} />
              </div>
              <div className="tab-pane fade" id="planner">
                <PlannersTab
                  eventData={eventData}
                  setEventData={setEventData}
                />
              </div>
              <div className="tab-pane fade" id="cater">
                <Caterstab eventData={eventData} setEventData={setEventData} />
              </div>
              <div className="tab-pane fade" id="photograph">
                <PhotographersTab
                  eventData={eventData}
                  setEventData={setEventData}
                />
              </div>
              <div className="tab-pane fade" id="preview">
                <PreviewTab
                  hostedEventId={hostedEventId}
                  eventData={eventData}
                />
              </div>
            </div>
          </>
        );
      } else {
        return (
          <BasicDetails
            setChangingBasicDetails={setChangingBasicDetails}
            eventData={eventData}
            setEventData={setEventData}
          />
        );
      }
    } else {
      return (
        <div className="text-center align-content-center h-50">
          <p>Event Not Found</p>
        </div>
      );
    }
  } else {
    return <NoPage loading />;
  }
};

export default HostEvent;
