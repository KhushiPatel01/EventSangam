import { useEffect, useState } from "react";
import { biError, fetchData, notify } from "../functions";

const SortFilter = ({
  setObjs,
  date,
  business,
  requiredObjIds = [],
  originalObjs = { current: [] },
}) => {
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [sortingBy, setSortingBy] = useState("");
  const [sortOrder, setSortOrder] = useState(-1);
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [requiredObjs, setRequiredObjs] = useState([]);

  useEffect(() => {
    const getStates = async () => {
      let data = await fetchData({
        method: "GET",
        fetchUrl: `business/get_states/${business}/${date}`,
      });
      if (!data.error) {
        setStates(data.states);
      } else {
        notify(biError, "Cannot Get Filteration Options!!!");
      }
    };

    getStates();
  }, [business, date]);

  useEffect(() => {
    let requiredObjs = originalObjs.current.filter((obj) =>
      requiredObjIds.includes(business === "v" ? obj.vid : obj.bid)
    );
    setRequiredObjs([...requiredObjs]);
  }, [requiredObjIds, business, originalObjs]);

  const filterByState = (state) => {
    let filtered = originalObjs.current.filter(
      (obj) =>
        obj.state === state &&
        !requiredObjIds.includes(business === "v" ? obj.vid : obj.bid)
    );
    return [...requiredObjs, ...filtered];
  };

  const filterByCity = (city) => {
    let filtered = originalObjs.current.filter(
      (obj) =>
        obj.state === state &&
        obj.city === city &&
        !requiredObjIds.includes(business === "v" ? obj.vid : obj.bid)
    );
    return [...requiredObjs, ...filtered];
  };

  const updateState = (new_state) => {
    setState(new_state);
    let filtered = filterByState(new_state);
    setObjs(filtered);
    setCity("");
    setCities(filtered.map((obj) => obj.city));
    setSortingBy("");
    setSortOrder(-1);
  };

  const updateCity = (new_city) => {
    setCity(new_city);
    setObjs(filterByCity(new_city));
  };

  const handleRatingsSort = (order) => {
    setSortingBy("ratings");
    setSortOrder(order);
    let filtered = originalObjs.current;
    if (city) {
      filtered = filterByCity(city);
    } else if (state) {
      filtered = filterByState(state);
    }
    filtered = filtered.sort((obj1, obj2) => obj1["ratings"] - obj2["ratings"]);
    if (order === 1) {
      filtered = filtered.reverse();
    }
    setObjs([...requiredObjs, ...filtered]);
  };

  const handlePriceSort = (order) => {
    setSortingBy("price");
    setSortOrder(order);
    let filtered = originalObjs.current;
    if (city) {
      filtered = filterByCity(city);
    } else if (state) {
      filtered = filterByState(state);
    }

    filtered = filtered.sort((obj1, obj2) => obj1["price"] - obj2["price"]);
    if (order === 1) {
      filtered = filtered.reverse();
    }
    setObjs([...requiredObjs, ...filtered]);
  };

  const handleReset = () => {
    setCity("");
    setState("");
    setSortingBy("");
    setSortOrder(-1);
    setCities([]);
    let filtered = originalObjs.current.filter(
      (obj) => !requiredObjIds.includes(business === "v" ? obj.vid : obj.bid)
    );
    setObjs([...requiredObjs, ...filtered]);
  };

  let ascRatings = sortingBy === "ratings" && sortOrder === 0;
  let ascPrice = sortingBy === "price" && sortOrder === 0;

  return (
    <>
      <div className="row m-2 sf align-items-center pb-2">
        <div className="dropdown dp col-6 col-md-2 mb-2 mb-md-0">
          <button
            className="cus_btn filledBtn block_md dropdown-toggle text-capitalize"
            type="button"
            data-bs-toggle="dropdown"
          >
            {state || "State"}
          </button>
          <div
            style={{ maxHeight: "50vh" }}
            className="dropdown-menu scrollable"
          >
            {states.map((state, index) => (
              <button
                type="button"
                onClick={() => {
                  updateState(state);
                }}
                key={`City ${index + 1}`}
                className="dropdown-item"
              >
                {state}
              </button>
            ))}
          </div>
        </div>
        <div className="dropdown dp col-6 col-md-2 mb-2 mb-md-0">
          <button
            className="cus_btn filledBtn block_md dropdown-toggle text-capitalize"
            type="button"
            data-bs-toggle="dropdown"
          >
            {city || "City"}
          </button>
          <div
            style={{ maxHeight: "50vh" }}
            className="dropdown-menu scrollable"
          >
            {cities.length ? (
              cities.map((city, index) => (
                <button
                  type="button"
                  onClick={() => {
                    updateCity(city);
                  }}
                  key={`City ${index + 1}`}
                  className="dropdown-item"
                >
                  {city}
                </button>
              ))
            ) : (
              <p className=" text-center m-auto">No State Selected</p>
            )}
          </div>
        </div>
        <div className="col-6 text-center col-md-3 mb-2 mb-md-0">
          <span className="me-2">Ratings</span>
          <button
            onClick={() => {
              handleRatingsSort(0);
            }}
            className={`outlinedBtn me-1 ${ascRatings ? "important" : ""}`}
          >
            <i className="bi bi-arrow-up"></i>
          </button>
          <button
            onClick={() => {
              handleRatingsSort(1);
            }}
            className={`outlinedBtn me-1 ${
              sortingBy === "ratings" && !ascRatings ? "important" : ""
            }`}
          >
            <i className="bi bi-arrow-down"></i>
          </button>
        </div>
        <div className="col-6 text-center col-md-3 mb-2 mb-md-0">
          <span className="me-2">Price</span>
          <button
            onClick={() => {
              handlePriceSort(0);
            }}
            className={`outlinedBtn me-1 ${ascPrice ? "important" : ""}`}
          >
            <i className="bi bi-arrow-up"></i>
          </button>
          <button
            onClick={() => {
              handlePriceSort(1);
            }}
            className={`outlinedBtn me-1 ${
              sortingBy === "price" && !ascPrice ? "important" : ""
            }`}
          >
            <i className="bi bi-arrow-down"></i>
          </button>
        </div>
        <div className="col-12 col-md-2 mb-2 mb-md-0">
          <button onClick={handleReset} className="block important">
            Reset
          </button>
        </div>
      </div>
    </>
  );
};

export default SortFilter;
