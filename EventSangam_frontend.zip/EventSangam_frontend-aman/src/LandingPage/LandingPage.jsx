import { useEffect, useRef } from "react";
import "./LandingPage.css";

const LandingPage = () => {
  const galleryRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible"); // Add the visible class
          observer.unobserve(entry.target); // Stop observing after it becomes visible
        }
      });
    });

    const images = galleryRef.current.querySelectorAll(".gallery img");
    images.forEach((image) => {
      observer.observe(image);
    });

    return () => {
      images.forEach((image) => {
        observer.unobserve(image);
      });
    };
  }, []);

  return (
    <div
      style={{ maxHeight: "100%" }}
      className="carousel-container scrollable"
    >
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <h1>Welcome to EventSangam</h1>
          <p>Your one-stop solution for all your event management needs.</p>
          <a href="/login" className="refBtn">
            Get Started
          </a>
        </div>
      </section>

      {/* Carousel Images */}
      <div className="gallery" ref={galleryRef}>
        <img
          src="https://i.insider.com/668e3e1139de72f47bc9e3d7?width=700"
          alt="Event 1"
        />
        <img
          src="https://www.outlandishevents.co.za/wp-content/uploads/2024/07/Classic-Indian-Themed-40th-Birthday-Party-Ishrat-Joosub-Outlandish-Events-36.jpg"
          alt="Event 2"
        />
        <img
          src="https://media.licdn.com/dms/image/D4D12AQFI09pPbqbuAg/article-cover_image-shrink_600_2000/0/1697714978117?e=2147483647&v=beta&t=0Q1tc_YH73jzhCSfDQadg7DQB1CRKfSjP-3yoi4On0E"
          alt="Event 3"
        />
        <img
          src="https://images.pexels.com/photos/3593432/pexels-photo-3593432.jpeg?auto=compress&cs=tinysrgb&w=600"
          alt="Event 4"
        />
        <img
          src="https://media.licdn.com/dms/image/D4D12AQEaS2l8b6SWbQ/article-cover_image-shrink_720_1280/0/1686893693538?e=2147483647&v=beta&t=WWpSX_8SlywNQwDx72Z_EGiprJlTZHI7_HTfVnc9vBM"
          alt="Event 5"
        />
        <img
          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScSXBv6reTVMb-KUqSNJGje21W2bQXWo5kew&s"
          alt=""
        />
      </div>
    </div>
  );
};

export default LandingPage;
