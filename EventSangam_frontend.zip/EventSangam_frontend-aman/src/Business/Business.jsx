import Ratings from "../HostEvent/Ratings";
import "./Business.css";

const Business = ({
  businessData,
  onAdd,
  onRemove,
  currentAddedBids,
  isExploring,
}) => {
  return (
    <div className="card business my-3">
      <div className="card-body">
        <h4>{businessData.name}</h4>
        <p className="fs-6">
          {businessData.address}
        </p>
        <div className="d-flex justify-content-between w-50 flex-column flex-md-row">
          <div>Ratings : {businessData.ratings}</div>
          <div>
            Price per {businessData.vid ? "Day" : "Hour"} : &#8377;{" "}
            {businessData.price}
          </div>
        </div>
        {isExploring && (
          <div>
            <Ratings business={businessData} />
          </div>
        )}
        <div className="card-footer d-flex justify-content-between align-items-center">
          <div className=" d-flex flex-column flex-md-row justify-content-md-between align-items-md-center w-50">
            <div>Email : {businessData.email}</div>
            <div>Phone : {businessData.phone}</div>
          </div>
          {!isExploring && (
            <div>
              {!currentAddedBids.includes(businessData.bid) ? (
                <button
                  onClick={() => {
                    onAdd(businessData);
                  }}
                  type="button"
                  className="important outlinedBtn"
                >
                  Add
                </button>
              ) : (
                <button
                  onClick={() => {
                    onRemove(businessData.bid);
                  }}
                  type="button"
                  className="important"
                >
                  Remove
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Business;
