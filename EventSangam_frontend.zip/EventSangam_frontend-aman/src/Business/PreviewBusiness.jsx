const PreviewBusiness = ({ businessData }) => {
  return (
    <div className="container-fluid">
      <h4>{businessData.name}</h4>
      <div className="row">
        <div className="col-6 col-md-3">State : {businessData.state}</div>
        <div className="col-6 col-md-3">City : {businessData.city}</div>
        <div className="col-6 col-md-3">Ratings : {businessData.ratings}</div>
        <div className="col-6 col-md-3">
          Price per {businessData.vid ? "Day" : "Hour"} : &#8377; {businessData.price}
        </div>
      </div>
    </div>
  );
};

export default PreviewBusiness;
