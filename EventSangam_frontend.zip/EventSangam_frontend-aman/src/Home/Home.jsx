import "./Home.css";
import { useEffect, useRef } from "react";

const SvgShapes = () => (
  <svg viewBox="0 0 200 200" className="svg-shape">
    <defs>
      <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{ stopColor: "#ff7e5f", stopOpacity: 1 }} />
        <stop offset="100%" style={{ stopColor: "#feb47b", stopOpacity: 1 }} />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="50" fill="url(#gradient1)" />
    <rect
      x="100"
      y="100"
      width="100"
      height="100"
      fill="none"
      stroke="#e6004c"
      strokeWidth="3"
    />
  </svg>
);

const Home = () => {
  const offerings = [
    {
      title: "Luxury Retreats",
      description:
        "Experience tranquility in the most serene locations. Indulge in personalized wellness programs, including spa treatments, yoga sessions, and guided nature walks. Enjoy gourmet meals crafted with local ingredients, all while surrounded by breathtaking views. Our dedicated staff ensures every detail is taken care of, allowing you to unwind and connect with yourself and nature. Discover the ultimate sanctuary for relaxation and rejuvenation.",
      imageUrl:
        "https://static.showit.co/800/_QczT6whQ4qVlFPYgAjM3w/69014/090a6701.jpg",
    },
    {
      title: "Gourmet Dining",
      description:
        "Savor exquisite meals crafted by top chefs. Our gourmet dining offerings not only satisfy your palate but also create memorable experiences that celebrate the joy of fine food and company. Indulge in a feast for the senses and discover the true meaning of culinary excellence.",
      imageUrl:
        "https://eventcracker.com/wp-content/uploads/2022/03/Kelly-256-scaled.jpeg",
    },
    {
      title: "Weddings",
      description:
        "Every bride dreams of having the perfect wedding, but planning that can be quite a task. Throw in all of the cultural nuances associated with ethnic weddings and the task can become overwhelming. We work directly with you and your families to handle all aspects of your wedding. The result is an extraordinary event that is just as you envisioned.",
      imageUrl:
        "https://eventcracker.com/wp-content/uploads/2020/06/Evening-Color-Chandelier-Mandap-2048x1536.jpg",
    },
    {
      title: "Social Events",
      description:
        "We are a full-service event planning company for any occasion – a Lavish Baby Shower, Birthday Party, Anniversary Party, or Sweet 16. Let us take care of the planning so that you and your guests can relax and enjoy your event stress-free. From location selection to invitation design to the perfect signature drink, we welcome the opportunity to assist you.",
      imageUrl:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzGPBoxnTAMZSHnr8rVc6C1XdQ57boULlbrg&s",
    },
    {
      title: "Wedding Bridal Party",
      description:
        "Step into an enchanting world where love and friendship intertwine. Our bridal party is a curated collection of cherished individuals, each radiating elegance and joy, reflecting the beauty of our journey together.",
      imageUrl: "https://eventcracker.com/wp-content/uploads/2021/02/0007.jpg",
    },
  ];

  const offeringsRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible"); // Add visible class
          observer.unobserve(entry.target); // Stop observing after it becomes visible
        }
      });
    });

    const offeringsItems =
      offeringsRef.current.querySelectorAll(".offering-item");
    offeringsItems.forEach((item) => {
      observer.observe(item);
    });

    return () => {
      offeringsItems.forEach((item) => {
        observer.unobserve(item);
      });
    };
  }, []);

  return (
    <div
      style={{ maxHeight: "100%" }}
      className="offerings-section scrollable"
      ref={offeringsRef}
    >
      <h1>Our Offerings</h1>
      <p>Explore a range of luxurious experiences tailored just for you.</p>
      <div className="offerings-grid">
        {offerings.map((offering, index) => (
          <div
            className={`offering-item ${index % 2 === 0 ? "reverse" : ""}`}
            key={index}
          >
            <div className="offering-image">
              <img src={offering.imageUrl} alt={offering.title} />
            </div>
            <div className="offering-info d-none d-md-flex">
              <SvgShapes />
              <h2>{offering.title}</h2>
              <p className="des">{offering.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
