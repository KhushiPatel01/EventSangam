import { useAppContext } from "../App/App";
import "./Profile.css";
import UserEvents from "../UserEvents/UserEvents";

const Profile = () => {
  let { client } = useAppContext();
  return (
    <div className="card card-body profile">
      <h4>{client.current.username}</h4>
      <div className="fs-6 d-flex">
        <div className="me-4">{client.current.email}</div>
        <div>{client.current.mobile}</div>
      </div>
      <p className="text-wrap">{client.current.address}</p>
      <div style={{ maxHeight: "70%" }}>
        <h5 className="text-center">Your Events</h5>
        <UserEvents />
      </div>
    </div>
  );
};

export default Profile;
