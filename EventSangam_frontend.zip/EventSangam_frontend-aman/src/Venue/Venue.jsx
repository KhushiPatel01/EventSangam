import Ratings from "../HostEvent/Ratings";
import "./Venue.css";

const Venue = ({ venue, addedVenueId, onAdd, onRemove, isExploring }) => {
  return (
    <div className=" container-fluid">
      <div className="row my-3 venue">
        <div
          id={`carousel_${venue.vid}`}
          className="carousel slide col-12 col-md-3"
          data-bs-ride="carousel"
        >
          <div className="carousel-inner">
            {venue.images.map((img, index) => (
              <div
                key={index}
                className={
                  index === 0 ? "carousel-item active" : "carousel-item"
                }
              >
                <img
                  src={img}
                  className="carousel-image d-block w-100"
                  alt={`${venue.name} Slide ${index + 1}`}
                />
              </div>
            ))}
          </div>
          <button
            className="carousel-control-prev"
            type="button"
            data-bs-target={`#carousel_${venue.vid}`}
            data-bs-slide="prev"
          >
            <span className="carousel-control-prev-icon"></span>
          </button>
          <button
            className="carousel-control-next"
            type="button"
            data-bs-target={`#carousel_${venue.vid}`}
            data-bs-slide="next"
          >
            <span className="carousel-control-next-icon"></span>
          </button>
        </div>
        <div className="col-md-9 col-12">
          <div className="card h-100">
            <div className="card-body">
              <h4 className="card-title">{venue.name}</h4>
              <p className="card-text">{venue.address}</p>
              <div className="row">
                <div className="col">Ratings : {venue.ratings || 0}</div>
                <div className="col">Price per Day : {venue.price || 0}</div>
              </div>
              {isExploring && <Ratings business={venue} />}
            </div>
            <div className="d-flex justify-content-between flex-column flex-md-row pb-2 px-2">
              <div className="d-flex justify-content-between flex-column flex-md-row w-75 pb-2 pb-md-0">
                <span>Email : {venue.email}</span>
                <span>Phone : {venue.phone}</span>
              </div>

              {!isExploring && !addedVenueId && (
                <div>
                  <button
                    onClick={onAdd}
                    className="important outlinedBtn block_md"
                  >
                    Add
                  </button>
                </div>
              )}

              {!isExploring && addedVenueId === venue.vid && (
                <div>
                  <button onClick={onRemove} className="important block_md">
                    Remove
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Venue;
