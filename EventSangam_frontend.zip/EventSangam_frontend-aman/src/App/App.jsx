import "./App.css";
import {
  NavLink,
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import React, {
  createContext,
  useContext,
  useRef,
  useState,
  useEffect,
} from "react";
import Home from "../Home/Home";
import HostEvent from "../HostEvent/HostEvent";
import Profile from "../Profile/Profile";
import Login from "../Login/Login";
import Register from "../Register/Register";
import NoPage from "../NoPage/NoPage";
import VenueExplore from "../Explore/VenueExplore";
import PlannerExplore from "../Explore/PlannerExplore";
import CaterExplore from "../Explore/CaterExplore";
import PhotographerExplore from "../Explore/PhotographerExplore";
import LandingPage from "../LandingPage/LandingPage";
import { fetchData, notify, biError } from "../functions";

const AppContext = createContext();
export const useAppContext = () => {
  return useContext(AppContext);
};

const App = () => {
  let client = useRef({
    rated_businesses: {},
    hosted_events: [],
  });
  const [loggedUser, setLoggedUser] = useState(null);
  const [loadingUser, setLoadingUser] = useState(localStorage.getItem("token"));

  useEffect(() => {
    let token = JSON.parse(localStorage.getItem("token"));
    if (token) {
      const getUser = async () => {
        let data = await fetchData({
          fetchUrl: `get_user/${token.cid}`,
          method: "GET",
        });

        if (!data.error && data.user) {
          setLoggedUser(data.user);
          client.current = { ...data.user };
        } else if (data.message) {
          notify(biError, data.message);
        } else {
          notify(biError, "Something Went Wrong!!!");
        }
        setLoadingUser(false);
      };
      getUser();
    }
  }, []);

  const LogOut = () => {
    localStorage.removeItem("token");
    window.location.pathname = "/";
  };

  return loadingUser ? (
    <NoPage loading />
  ) : (
    <Router>
      <div
        style={{ width: "100vw", height: "100vh", overflow: "hidden" }}
        className="container-fluid"
      >
        <>
          <AppContext.Provider value={{ client }}>
            {loggedUser && (
              <nav className="navbar navbar-expand-md custom-nav">
                <div className="container-fluid">
                  <NavLink
                    style={{ color: "var(--important_bg)" }}
                    className="navbar-brand"
                    to="/home"
                  >
                    EventSangam
                  </NavLink>
                  <button
                    className="navbar-toggler d-lg-none outlinedBtn important"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#nav"
                  >
                    <span className="bi bi-three-dots"></span>
                  </button>
                  <div className="collapse navbar-collapse" id="nav">
                    <ul className="navbar-nav me-auto mt-2 mt-lg-0">
                      <li className="nav-item">
                        <NavLink className="nav-link" to="/home">
                          Home
                        </NavLink>
                      </li>
                      <li className="nav-item">
                        <NavLink className="nav-link" to="/hostEvent">
                          Host Event
                        </NavLink>
                      </li>

                      <div className="dropdown nav-item align-content-center dp">
                        <button
                          className="dropdown-toggle important cus_btn"
                          type="button"
                          id="explore-dp"
                          data-bs-toggle="dropdown"
                        >
                          Explore
                        </button>
                        <div
                          className="dropdown-menu py-1 imp"
                          aria-labelledby="explore-dp"
                        >
                          <NavLink
                            className="dropdown-item py-1 nav-link"
                            to="/explore/venues"
                          >
                            Venues
                          </NavLink>
                          <NavLink
                            className="dropdown-item py-1 nav-link"
                            to="/explore/planners"
                          >
                            Planners
                          </NavLink>
                          <NavLink
                            className="dropdown-item py-1 nav-link"
                            to="/explore/caters"
                          >
                            Caters
                          </NavLink>
                          <NavLink
                            className="dropdown-item py-1 nav-link"
                            to="/explore/photographers"
                          >
                            Photographers
                          </NavLink>
                        </div>
                      </div>
                    </ul>
                    <div className="navbar-nav ms-auto mt-2 mt-lg-0">
                      <div className="nav-item">
                        <NavLink className="nav-link" to="/logout">
                          Log Out
                        </NavLink>
                      </div>
                      <div className="nav-item">
                        <NavLink className="nav-link" to="/profile">
                          Profile
                        </NavLink>
                      </div>
                    </div>
                  </div>
                </div>
              </nav>
            )}
            <div
              style={{
                height: loggedUser ? "90%" : "100%",
                overflow: "hidden",
              }}
            >
              <Routes>
                <Route
                  path="/"
                  element={
                    loggedUser ? <Navigate to={"/home"} /> : <LandingPage />
                  }
                ></Route>
                <Route
                  path="*"
                  element={
                    <NoPage notFoundText={"No Page Found for this Path."} />
                  }
                ></Route>
                <Route
                  path="/login"
                  element={
                    <Login setLoggedUser={setLoggedUser} client={client} />
                  }
                ></Route>
                <Route
                  path="/register"
                  element={
                    <Register setLoggedUser={setLoggedUser} client={client} />
                  }
                ></Route>
                <Route path="/home" element={<Home />}></Route>
                <Route
                  path="/hostEvent/:hostedEventId?"
                  element={<HostEvent />}
                ></Route>
                <Route
                  path="/explore/venues"
                  element={<VenueExplore />}
                ></Route>
                <Route
                  path="/explore/planners"
                  element={<PlannerExplore />}
                ></Route>
                <Route
                  path="/explore/caters"
                  element={<CaterExplore />}
                ></Route>
                <Route
                  path="/explore/photographers"
                  element={<PhotographerExplore />}
                ></Route>
                <Route path="/profile" element={<Profile />}></Route>
                <Route path="/logout" element={<LogOut />}></Route>
              </Routes>
            </div>
          </AppContext.Provider>
        </>
      </div>
    </Router>
  );
};

export default App;
