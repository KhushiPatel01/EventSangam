import { useState } from "react";
import "./Login.css";
import { biError, fetchData, notify } from "../functions";
import { Link, useNavigate } from "react-router-dom";

const Login = ({ setLoggedUser, client }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  // Use this on Inputs onChange = handleChange
  // Name of the inputs should be username and password only
  const handleChange = (e) => {
    let { name, value } = e.target;
    if (value.trim()) {
      setFormData((prev) => {
        return { ...prev, [name]: value };
      });
    }
  };

  // In Form <form onSumbit = handleSubmit><button type="submit"></button></form>
  const handleSubmit = async (e) => {
    e.preventDefault();
    let data = await fetchData({ fetchUrl: "login", data: formData });
    if (!data.error && data.user) {
      setLoggedUser(data.user);
      client.current = { ...data.user };
      localStorage.setItem("token", JSON.stringify(data.token));
      navigate("/");
    } else if (data.message) {
      notify(biError, data.message);
    } else {
      notify(biError, "Something Went Wrong!!!");
    }
  };
  return (
    <>
      <section className="login-container">
        <div
          className="color"
          style={{
            top: "-350px",
            width: "700px",
            height: "700px",
            background: "#ff359b",
          }}
        ></div>
        <div
          className="color"
          style={{
            bottom: "-100px",
            left: "300px",
            width: "600px",
            height: "600px",
            background: "#ffdd87",
          }}
        ></div>
        <div
          className="color"
          style={{
            bottom: "50px",
            right: "400px",
            width: "400px",
            height: "400px",
            background: "#00d2ff",
          }}
        ></div>
        <div className="box">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="square" style={{ "--i": i }}></div>
          ))}
          <div className="container">
            <div className="form">
              <h2>Login Form</h2>
              <form onSubmit={handleSubmit}>
                <div className="inputbox">
                  <input
                    type="text"
                    placeholder="username"
                    name="username"
                    onChange={handleChange}
                    autoComplete="username"
                  />
                </div>
                <div className="inputbox">
                  <input
                    type="password"
                    placeholder="password"
                    name="password"
                    onChange={handleChange}
                    autoComplete="password"
                  />
                </div>
                <div className="inputbox">
                  <input type="submit" value="Login" />
                </div>
                <p className="toRegister">
                  Don't have an account?<Link to="/register">Sign Up</Link>
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Login;
