const backendUrl = "http://127.0.0.1:8000/user/";

function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== "") {
    const cookies = document.cookie.split(";");
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      if (cookie.substring(0, name.length + 1) === name + "=") {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}

export const biSuccess = "bi-check-circle";
export const biSearch = "bi-search";
export const biError = "bi-exclamation-circle";
export const biEdit = "bi-pencil";
export const biDelete = "bi-trash";
export const process = "spinner-border spinner-border-sm";
export const notFound = "bi-x-circle";

export function notify(iconClass, notificationText) {
  deNotify();

  const notificationDiv = document.createElement("div");
  notificationDiv.classList.add("notification", "outlinedBtn");

  const iconElement = document.createElement("i");
  iconElement.className = `bi ${iconClass}`;

  const buttonElement = document.createElement("button");
  buttonElement.appendChild(iconElement);
  buttonElement.classList.add("important");

  notificationDiv.appendChild(buttonElement);
  notificationDiv.appendChild(document.createTextNode(` ${notificationText}`));
  document.body.appendChild(notificationDiv);

  notificationDiv.addEventListener("animationend", (event) => {
    if (event.animationName === "notifyOut") {
      notificationDiv.remove();
    }
  });
}

export function deNotify() {
  const existingNotification = document.querySelector(".notification");
  if (existingNotification) {
    existingNotification.remove();
  }
}

const csrftoken = getCookie("csrftoken");

export async function fetchData({
  data = {},
  fetchUrl = "test",
  sendType = "application/json",
  retType = "application/json",
  method = "POST",
} = {}) {
  let dataToFetch;
  try {
    let fullUrl = `${backendUrl}${fetchUrl}`;
    let options = {
      headers: {
        "Content-type": sendType,
        "X-CSRFToken": csrftoken,
        Accept: retType,
      },
      method,
    };

    if (method !== "GET") {
      fullUrl += "/";
      options.body = JSON.stringify(data);
    }

    dataToFetch = await fetch(fullUrl, options);

    return retType === "application/json"
      ? await dataToFetch.json()
      : await dataToFetch.text();
  } catch (error) {
    return { error: error.message };
  }
}

export const getMinMaxDates = () => {
  const today = new Date();
  const minDate = today.toISOString().split("T")[0];
  const maxDate = new Date(today.setFullYear(today.getFullYear() + 10))
    .toISOString()
    .split("T")[0];

  return { minDate, maxDate };
};
