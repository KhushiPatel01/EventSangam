from datetime import datetime, timedelta
import time
from django.http import JsonResponse
from django.urls import include, path
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
import json
from pymongo import MongoClient
import bcrypt
from env import dbURL

client = MongoClient(dbURL)
db = client["EventSangamDatabase"]
users_collection = db["User"]


@csrf_exempt
@require_http_methods(["POST"])
def register(request):
    try:
        data = json.loads(request.body)
        username = data.get("username")
        password = data.get("password")
        email = data.get("email")
        mobile = data.get("mobile")
        address = data.get("address")

        if not username or not password or not email or not mobile or not address:
            return JsonResponse(
                {"message": "All mandatory fields must be provided"}, status=400
            )

        if users_collection.find_one({"username": username}):
            return JsonResponse({"message": "Username already exists"}, status=400)

        hashed_password = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())

        new_user = {
            "username": username,
            "password": hashed_password,
            "email": email,
            "mobile": mobile,
            "address": address,
            "hosted_events": [],
            "rated_businesses": {},
        }

        result = users_collection.insert_one(new_user)
        cid = str(result.inserted_id)
        del new_user["_id"]
        del new_user["password"]
        new_user["cid"] = cid

        users_collection.update_one({"_id": result.inserted_id}, {"$set": {"cid": cid}})

        token = {
            "cid": cid,
            "exp": (datetime.now() + timedelta(days=10)).strftime("%Y-%m-%d"),
        }

        return JsonResponse(
            {
                "message": "User registered successfully",
                "user": new_user,
                "token": token,
            },
            status=201,
        )

    except Exception as e:
        return JsonResponse(
            {"error": "Registration failed because " + str(e)},
            status=500,
        )


@csrf_exempt
@require_http_methods(["POST"])
def login(request):
    try:
        data = json.loads(request.body)
        username = data.get("username")
        password = data.get("password")

        user = users_collection.find_one({"username": username}, {"_id": 0})
        if user and bcrypt.checkpw(password.encode("utf-8"), user["password"]):
            del user["password"]

            token = {
                "cid": user["cid"],
                "exp": (datetime.now() + timedelta(days=10)).strftime("%Y-%m-%d"),
            }

            return JsonResponse(
                {"message": "Login successful", "user": user, "token": token},
                status=200,
            )

        return JsonResponse({"message": "User not Found"}, status=401)

    except Exception as e:
        return JsonResponse({"error": "Login failed"}, status=500)


@csrf_exempt
@require_http_methods(["POST"])
def delete(request):
    try:
        data = json.loads(request.body)
        username = data.get("username")
        password = data.get("password")

        user = users_collection.find_one({"username": username})

        if user and bcrypt.checkpw(password.encode("utf-8"), user["password"]):
            users_collection.delete_one(user)
            return JsonResponse({"message": "Deletion successful"}, status=200)

        return JsonResponse({"error": "Invalid credentials"}, status=401)

    except Exception as e:
        return JsonResponse({"error": "Deletion failed"}, status=500)


@csrf_exempt
@require_http_methods(["GET"])
def get_user(request, cid):
    try:
        user = users_collection.find_one({"cid": cid}, {"_id": 0, "password": 0})
        if user:
            return JsonResponse({"user": user}, status=200)
        else:
            return JsonResponse({"message": "User not Found"}, status=404)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


urlpatterns = [
    path("register/", register, name="register"),
    path("login/", login, name="login"),
    path("get_user/<str:cid>", get_user, name="get_user"),
    path("delete/", delete, name="delete"),
    path("event/", include("backend.event_urls")),
    path("business/", include("backend.business_urls")),
]
