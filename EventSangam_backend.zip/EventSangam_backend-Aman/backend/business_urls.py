from django.http import JsonResponse
from django.urls import path
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from pymongo import MongoClient
from env import dbURL

db_client = MongoClient(dbURL)
db = db_client["EventSangamDatabase"]
business_collection = db["Business"]
venue_collection = db["Venue"]
client_collection = db["User"]


@csrf_exempt
@require_http_methods(["GET"])
def update_ratings(request, new_ratings, old_ratings, cid, col, id):
    try:
        collection = venue_collection if col == "v" else business_collection
        if new_ratings:
            client_collection.update_one(
                {"cid": cid}, {"$set": {f"rated_businesses.{id}": new_ratings}}
            )
        else:
            client_collection.update_one(
                {"cid": cid}, {"$unset": {f"rated_businesses.{id}": ""}}
            )

        business = collection.find_one({"vid" if col == "v" else "bid": id})
        ratings_dict = business["all_ratings"]
        ratings_dict = {int(k): v for k, v in list(ratings_dict.items())}

        if old_ratings:
            ratings_dict[old_ratings] -= 1

        if new_ratings:
            ratings_dict[new_ratings] += 1

        ratings = round(sum([k * v for k, v in list(ratings_dict.items())]), 1)
        ratings_dict = {str(k): v for k, v in list(ratings_dict.items())}

        business_collection.update_one(
            {"vid" if col == "v" else "bid": id},
            {"$set": {"all_ratings": ratings_dict, "ratings": ratings}},
        )

        return JsonResponse({"ratings": ratings}, status=200)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@csrf_exempt
@require_http_methods(["GET"])
def get_states(request, business, date):
    try:
        collection = venue_collection if business == "v" else business_collection
        return JsonResponse(
            {
                "states": (
                    collection.distinct("state", {"booked_for": {"$ne": date}})
                    if business == "v"
                    else collection.distinct(
                        "state", {"type": business, "booked_for": {"$ne": date}}
                    )
                ),
            },
            status=200,
        )
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@csrf_exempt
@require_http_methods(["GET"])
def get_available_venues(request, date=None):
    try:
        venues = list(venue_collection.find({}, {"_id": 0}))

        if date:
            venues = list(
                venue_collection.find({"booked_for": {"$ne": date}}, {"_id": 0})
            )

        return JsonResponse(
            {"venues": venues},
            status=200,
        )
    except Exception as e:
        return JsonResponse({"error": str(e)})


@csrf_exempt
@require_http_methods(["GET"])
def get_available_planners(request, date=None):
    try:
        planners = list(business_collection.find({"type": "Planning"}, {"_id": 0}))
        if date:
            planners = list(
                business_collection.find(
                    {"type": "Planning", "booked_for": {"$ne": date}}, {"_id": 0}
                )
            )
        return JsonResponse(
            {"planners": planners},
            status=200,
        )
    except Exception as e:
        return JsonResponse({"error": str(e)})


@csrf_exempt
@require_http_methods(["GET"])
def get_available_photographers(request, date=None):
    try:
        photographers = list(
            business_collection.find({"type": "Photography"}, {"_id": 0})
        )
        if date:
            photographers = list(
                business_collection.find(
                    {"type": "Photography", "booked_for": {"$ne": date}}, {"_id": 0}
                )
            )
        return JsonResponse(
            {"photographers": photographers},
            status=200,
        )
    except Exception as e:
        return JsonResponse({"error": str(e)})


@csrf_exempt
@require_http_methods(["GET"])
def get_available_caters(request, date=None):
    try:
        caters = list(business_collection.find({"type": "Catering"}, {"_id": 0}))
        if date:
            caters = list(
                business_collection.find(
                    {"type": "Catering", "booked_for": {"$ne": date}}, {"_id": 0}
                )
            )
        return JsonResponse(
            {"caters": caters},
            status=200,
        )
    except Exception as e:
        return JsonResponse({"error": str(e)})


urlpatterns = [
    path(
        "update_ratings/<int:new_ratings>/<int:old_ratings>/<str:cid>/<str:col>/<str:id>",
        update_ratings,
        name="update_ratings",
    ),
    path(
        "get_states/<str:business>/<str:date>",
        get_states,
        name="get_states",
    ),
    path(
        "get_available_venues/<str:date>",
        get_available_venues,
        name="get_available_venues",
    ),
    path(
        "get_available_venues/",
        get_available_venues,
        name="get_available_venues",
    ),
    path(
        "get_available_planners/<str:date>",
        get_available_planners,
        name="get_available_planners",
    ),
    path(
        "get_available_planners/",
        get_available_planners,
        name="get_available_planners",
    ),
    path(
        "get_available_photographers/<str:date>",
        get_available_photographers,
        name="get_available_photographers",
    ),
    path(
        "get_available_photographers/",
        get_available_photographers,
        name="get_available_photographers",
    ),
    path(
        "get_available_caters/<str:date>",
        get_available_caters,
        name="get_available_caters",
    ),
    path(
        "get_available_caters/",
        get_available_caters,
        name="get_available_caters",
    ),
]
