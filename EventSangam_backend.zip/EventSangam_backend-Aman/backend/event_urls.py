from datetime import datetime
from django.http import JsonResponse
from django.urls import path
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
import json
from pymongo import MongoClient
from env import dbURL

db_client = MongoClient(dbURL)
db = db_client["EventSangamDatabase"]
events_collection = db["Event"]
business_collection = db["Business"]
users_collection = db["User"]
venue_collection = db["Venue"]


@csrf_exempt
@require_http_methods(["POST"])
def host_event(request):
    try:
        data = json.loads(request.body)

        event_type = data.get("event_type")
        cid = data.get("cid")
        data["status"] = "planned"

        if not event_type or not cid:
            return JsonResponse(
                {"error": "Event type and Client are required"}, status=400
            )

        client = users_collection.find_one({"cid": cid}, {"_id": 0, "password": 0})
        if not client:
            return JsonResponse({"message": "Client not found"}, status=404)

        create_date = datetime.today().date()
        data["create_date"] = str(create_date)
        eid = events_collection.insert_one(data).inserted_id
        added_event = events_collection.find_one_and_update(
            {"_id": eid}, {"$set": {"eid": str(eid)}}, {"_id": 0}
        )
        users_collection.update_one(
            {"cid": cid}, {"$push": {"hosted_events": str(eid)}}
        )
        added_event["create_date"] = str(create_date)

        business_collection.update_many(
            {
                "bid": {
                    "$in": added_event["planners"]
                    + added_event["caters"]
                    + added_event["photographers"]
                }
            },
            {"$set": {"booked_for": added_event["date"]}},
        )

        venue_collection.update_one(
            {"vid": data["venue"]},
            {"$set": {"booked_for": added_event["date"]}},
        )

        return JsonResponse(
            {"message": "Event Planned successfully", "event": added_event},
            status=201,
        )
    except Exception as e:
        return JsonResponse({"error": f"Failed to host event: {str(e)}"}, status=500)


@csrf_exempt
@require_http_methods(["POST"])
def update_event(request):
    try:
        data = json.loads(request.body)
        eid = data.get("eid", "")
        event = events_collection.find_one({"eid": eid}, {"_id": 0})

        if not eid or not event:
            return JsonResponse({"message": "Event Not Found"}, status=404)

        business_collection.update_many(
            {
                "bid": {
                    "$in": event["planners"] + event["caters"] + event["photographers"]
                }
            },
            {"$unset": {"booked_for": ""}},
        )

        venue_collection.update_one(
            {"vid": event["venue"]},
            {"$unset": {"booked_for": ""}},
        )

        event = events_collection.find_one_and_update(
            {"eid": eid}, {"$set": data}, {"_id": 0}
        )
        business_collection.update_many(
            {
                "bid": {
                    "$in": event["planners"] + event["caters"] + event["photographers"]
                }
            },
            {"$set": {"booked_for": data["date"]}},
        )

        venue_collection.update_one(
            {"vid": event["venue"]},
            {"$set": {"booked_for": event["date"]}},
        )

        return JsonResponse(
            {"message": "Event Updated SuccessFully", "event": event}, status=200
        )

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@csrf_exempt
@require_http_methods(["GET"])
def cancel_event(request, eid, cid):
    try:
        event = events_collection.find_one({"eid": eid}, {"_id": 0})
        if not event:
            return JsonResponse({"message": "Event not found"}, status=404)

        events_collection.delete_one({"eid": eid})
        users_collection.update_one({"cid": cid}, {"$pull": {"hosted_events": eid}})
        business_collection.update_many(
            {
                "bid": {
                    "$in": event["planners"] + event["caters"] + event["photographers"]
                }
            },
            {"$unset": {"booked_for": ""}},
        )

        venue_collection.update_one(
            {"vid": event["venue"]},
            {"$unset": {"booked_for": ""}},
        )

        return JsonResponse(
            {"message": "Event Canceled successfully", "event": event}, status=200
        )
    except Exception as e:
        return JsonResponse({"error": "Failed to delete event"}, status=500)


@csrf_exempt
@require_http_methods(["GET"])
def fetch_event(request, eid):
    try:
        event = events_collection.find_one({"eid": eid}, {"_id": 0})
        if not event:
            return JsonResponse({"message": "Event not Found"}, status=404)
        planners, photographers, caters, venue = (
            event["planners"],
            event["photographers"],
            event["caters"],
            event["venue"],
        )

        for index, planner in enumerate(planners):
            planners[index] = business_collection.find_one({"bid": planner}, {"_id": 0})
        for index, photographer in enumerate(photographers):
            photographers[index] = business_collection.find_one(
                {"bid": photographer}, {"_id": 0}
            )
        for index, cater in enumerate(caters):
            caters[index] = business_collection.find_one({"bid": cater}, {"_id": 0})
        venue = venue_collection.find_one({"vid": venue}, {"_id": 0})

        event["planners"] = planners
        event["photographers"] = photographers
        event["caters"] = caters
        event["venue"] = venue

        return JsonResponse({"event": event}, status=200)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@csrf_exempt
@require_http_methods(["GET"])
def fetch_user_events(request, cid):
    try:
        client = users_collection.find_one({"cid": cid})
        if not client:
            return JsonResponse({"message": "Client not Found"}, status=404)

        for event_index, eid in enumerate(client["hosted_events"]):
            event = events_collection.find_one({"eid": eid}, {"_id": 0})
            if event:
                planners, photographers, caters, venue = (
                    event["planners"],
                    event["photographers"],
                    event["caters"],
                    event["venue"],
                )

                for index, planner in enumerate(planners):
                    planners[index] = business_collection.find_one(
                        {"bid": planner}, {"_id": 0}
                    )
                for index, photographer in enumerate(photographers):
                    photographers[index] = business_collection.find_one(
                        {"bid": photographer}, {"_id": 0}
                    )
                for index, cater in enumerate(caters):
                    caters[index] = business_collection.find_one(
                        {"bid": cater}, {"_id": 0}
                    )
                venue = venue_collection.find_one({"vid": venue}, {"_id": 0})

                event["planners"] = planners
                event["photographers"] = photographers
                event["caters"] = caters
                event["venue"] = venue

                client["hosted_events"][event_index] = event

        return JsonResponse({"events": client["hosted_events"]}, status=200)
    except Exception as e:
        return JsonResponse({"error": "Failed to fetch event"}, status=500)


@csrf_exempt
@require_http_methods(["GET"])
def mark_complete(request, eid):
    try:
        event = events_collection.find_one_and_update(
            {"eid": eid}, {"$set": {"status": "completed"}}
        )

        for business in event["planners"] + event["caters"] + event["photographers"]:
            business_collection.update_one(
                {"bid": business["bid"]}, {"$unset": {"booked_for": ""}}
            )
        venue_collection.update_one(
            {"vid": event["venue"]}, {"$unset": {"booked_for": ""}}
        )
        return JsonResponse({"updated": True}, status=200)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


urlpatterns = [
    path("host_event/", host_event, name="host_event"),
    path("update_event/", update_event, name="update_event"),
    path("cancel_event/<str:eid>/<str:cid>", cancel_event, name="cancel_event"),
    path("fetch_event/<str:eid>", fetch_event, name="fetch_event"),
    path("mark_complete/<str:eid>", mark_complete, name="mark_complete"),
    path("fetch_user_events/<str:cid>", fetch_user_events, name="fetch_user_events"),
]
